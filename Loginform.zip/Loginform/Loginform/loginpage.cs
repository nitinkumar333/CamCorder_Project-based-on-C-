﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Loginform
{
    public partial class loginpage : Form
    {
        public loginpage()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-D78R3BD;Initial Catalog=Data2;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from Registration where Username='" + textBox1.Text + "' and Password ='" + textBox2.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                Menu ss = new Menu();
                ss.Show();
               
            }
            else
            {
                MessageBox.Show("Username/Password is incorrect. Please try again!!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            registration rg = new registration();
            rg.Show();
            this.Hide();
        }

        /* private void button3_Click(object sender, EventArgs e)
         {
             Register rg = new Register();
             rg.Show();
         }*/
    }
}
